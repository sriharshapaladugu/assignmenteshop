const TOKEN_KEY = 'up-grad-shop-token';

// Function to set the JWT token in localStorage
export const setToken = (token) => {
    localStorage.setItem(TOKEN_KEY, token);
};

// Function to get the JWT token from localStorage
export const getToken = () => {
    return localStorage.getItem(TOKEN_KEY);
};

// Function to remove the JWT token from localStorage (logout)
export const clearToken = () => {
    localStorage.removeItem(TOKEN_KEY);
};
