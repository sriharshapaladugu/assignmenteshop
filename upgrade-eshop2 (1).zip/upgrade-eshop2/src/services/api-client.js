import axios from 'axios';
import {environment as env} from "../environment";


const axiosInstance = axios.create({
    baseURL: env.BASE_URL,
});

// Add an interceptor to include the token in the request headers
axiosInstance.interceptors.request.use(
    config => {
        const token = localStorage.getItem('token');
        if (token) {
            config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
    },
    error => {
        return Promise.reject(error);
    }
);

class APIClient {

    constructor(endpoint) {
        this.endpoint = endpoint;
    }

    login = (requestConfig) => {
        return axiosInstance
            .post(this.endpoint, requestConfig)
            .then((res) => res.data);
    };


}

export default APIClient;
