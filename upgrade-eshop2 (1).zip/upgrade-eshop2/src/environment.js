export const environment = {
    BASE_URL: 'http://localhost:8080/api',
    LOGIN_URL: '/auth/signin',
    SIGNUP_URL: '/auth/signup'
}