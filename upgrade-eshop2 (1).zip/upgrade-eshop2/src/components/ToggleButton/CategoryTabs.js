import React, { useState } from 'react';
import ToggleButton from '@mui/material/ToggleButton';
import ToggleButtonGroup from '@mui/material/ToggleButtonGroup';

function CategoryTabs({ categories, selectedCategory, onSelectCategory }) {
    const [alignment, setAlignment] = useState(selectedCategory);

    const handleAlignment = (event, newAlignment) => {
        if (newAlignment !== null) {
            setAlignment(newAlignment);
            onSelectCategory(newAlignment);
        }
    };

    return (
        <ToggleButtonGroup sx={{ marginBottom: 2 }}
            value={alignment}
            exclusive
            onChange={handleAlignment}
            aria-label="Category Tabs"
        >
            {categories.map((category) => (
                <ToggleButton key={category} value={category} sx={{ minWidth: 100 }}>
                    {category}
                </ToggleButton>
            ))}
        </ToggleButtonGroup>
    );
}

export default CategoryTabs;
