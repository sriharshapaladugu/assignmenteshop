import React from 'react';
import { FormControl, InputLabel, Select, MenuItem } from '@mui/material';

function SortBy({ options, selectedOption, onOptionChange }) {

    const sortByProducts = () => {

    };

    return (
        <FormControl  sx={{ m: 1, minWidth: 120 }}>
            <InputLabel id="sort-by-label">Sort By</InputLabel>
            <Select
                labelId="sort-by-label"
                id="sort-by-select"
                value={selectedOption}
                onChange={onOptionChange}
                label="Sort By">
                {options.map((option) => (
                    <MenuItem key={option.value} value={option.value} onClick={sortByProducts()}>
                        {option.label}
                    </MenuItem>
                ))}
            </Select>
        </FormControl>
    );
}

export default SortBy;
