import React, {useState} from 'react';
import {Avatar, Button, Link, List, Paper, TextField, Typography} from '@mui/material';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import {deepOrange} from '@mui/material/colors';

import './Login.css';
import Box from "@mui/material/Box";
import APIClient from "../../services/api-client";
import {environment as env} from "../../environment";
import {setToken} from "../../services/tokenService";
import {useNavigate} from "react-router-dom";

function Login() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const navigate = useNavigate();


    const handleEmailChange = (e) => {
        setEmail(e.target.value);
    };

    const handlePasswordChange = (e) => {
        setPassword(e.target.value);
    };

    const handleLogin = () => {
        // Add your login logic here (e.g., API request)
        // You can access the 'email' and 'password' state variables
        // for sending the user's input to the server.


        const requestOptions = {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                username: "email_jqaar@kkk.com", // "email_nonhf@test.com", // email,
                password: "password_qgiua", // "password_adr5n" // password
            })
        };

        const apiClient = new APIClient(env.LOGIN_URL);
        apiClient.login(JSON.parse(requestOptions.body))
            .then(({token, role}) => {

                setToken(token);

                navigate("/", { state: { isLoggedIn: true, isAdmin: !(role === 'ADMIN')  } });

            })
            .catch((err) => {
                console.log(err)
            });


    };

    return (<Paper elevation={3} style={{maxWidth: '400px', margin: '20px auto', padding: '20px'}}>
        <Box sx={{justifyContent: 'center', display: 'flex'}}>
            <Avatar sx={{bgcolor: deepOrange[500]}}>
                <LockOutlinedIcon color="primary" style={{fontSize: 30, margin: '0 auto', color: 'white'}}/>
            </Avatar>

        </Box>
        <Typography component="div" gutterBottom sx={{justifyContent: 'center', display: 'flex'}}>
            Sign In
        </Typography>


        <TextField
            label="Email"
            variant="outlined"
            fullWidth
            margin="normal"
            value={email}
            onChange={handleEmailChange}
        />
        <TextField
            label="Password"
            variant="outlined"
            fullWidth
            margin="normal"
            type="password"
            value={password}
            onChange={handlePasswordChange}
        />
        <Button variant="contained" color="primary" fullWidth onClick={handleLogin} sx={{marginY: 2, paddingY: 1.4}}>
            Log In
        </Button>

        <List sx={{marginY: 2}}>
            Did not sign up yet? <Link href={'/signup'}> Sign up here.</Link>
        </List>
    </Paper>);
}

export default Login;
