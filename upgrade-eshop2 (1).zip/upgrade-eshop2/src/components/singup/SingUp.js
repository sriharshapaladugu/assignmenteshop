import React, {useState} from 'react';
import {Avatar, Button, Link, List, Paper, TextField, Typography} from '@mui/material';
import Box from "@mui/material/Box";
import {deepOrange} from "@mui/material/colors";
import LockOutlinedIcon from "@mui/icons-material/LockOutlined";
import { useNavigate } from "react-router-dom";

function Signup() {
    const [fullName, setFullName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [con_password, setConPassword] = useState('');
    const [contact_number, setContactNumber] = useState('');

    const navigate = useNavigate();


    const handleFullNameChange = (e) => {
        setFullName(e.target.value);
    };

    const handleContactNumberChange = (e) => {
        setContactNumber(e.target.value);
    }

    const handleConPasswordChange = (e) => {

        setConPassword(e.target.value);
    }

    const handleConPasswordBlur = (e) => {
        const rePwd = e.target.value;
        if (rePwd !== password) {
            alert("Password not match");
        }
    }


    const handleEmailChange = (e) => {
        setEmail(e.target.value);
    };

    const handlePasswordChange = (e) => {
        setPassword(e.target.value);
    };

    const handleSignup = () => {
        const requestOptions = {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                    "email": "email_nonhf@test2.com",
                    "role": [
                        "ADMIN",
                        "USER"
                    ],
                    "password": "password_adr5n",
                    "firstName": "firstName_olyvw",
                    "lastName": "lastName_d8s66",
                    "contactNumber": "contactNumber_8vf87"
                })
        };
        fetch('http://localhost:8080/api/auth/signup', requestOptions)
            .then(response => response.json())
            .then(data => {
                console.log(data);
                navigate("/", { state: { isLoggedIn: true, isAdmin: false  } });
            }).catch((err) => {
            console.log(err)
        });

    };

    return (
        <Paper elevation={3} style={{maxWidth: '400px', margin: '20px auto', padding: '20px'}}>
            <Box sx={{justifyContent: 'center', display: 'flex'}}>
                <Avatar sx={{bgcolor: deepOrange[500]}}>
                    <LockOutlinedIcon color="primary" style={{fontSize: 30, margin: '0 auto', color: 'white'}}/>
                </Avatar>

            </Box>
            <Typography component="div" gutterBottom sx={{justifyContent: 'center', display: 'flex'}}>
                Sign Up
            </Typography>

            <TextField
                label="Full Name"
                variant="outlined"
                fullWidth
                margin="normal"
                value={fullName}
                onChange={handleFullNameChange}
            />
            <TextField
                label="Email"
                variant="outlined"
                fullWidth
                margin="normal"
                value={email}
                onChange={handleEmailChange}
            />
            <TextField
                label="Password"
                variant="outlined"
                fullWidth
                margin="normal"
                type="password"
                value={password}
                onChange={handlePasswordChange}
            />

            <TextField
                label="Confirm Password"
                variant="outlined"
                fullWidth
                margin="normal"
                type="password"
                value={con_password}
                onChange={handleConPasswordChange}
                onBlur={handleConPasswordBlur}
            />

            <TextField
                label="Contact Number"
                variant="outlined"
                fullWidth
                margin="normal"
                type="number"
                value={contact_number}
                onChange={handleContactNumberChange}
            />
            <Button variant="contained" color="primary" fullWidth onClick={handleSignup}
                    sx={{marginY: 2, paddingY: 1.4}}>
                Sign Up
            </Button>

            <List sx={{marginY: 2, textAlign: 'right'}}>
                Already have an account? <Link href={'/login'}> Log in here.</Link>
            </List>
        </Paper>
    );
}

export default Signup;
