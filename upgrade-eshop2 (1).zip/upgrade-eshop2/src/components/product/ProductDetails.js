// ProductDetails.js
import React, { useState, useEffect } from 'react';
import { Container, Typography, Card, CardContent, CardMedia, TextField, Button } from '@mui/material';
import Box from "@mui/material/Box";

const ProductDetails = ({product= {}, isLoggedIn, isAdmin}) => {
    const [quantity, setQuantity] = useState(1);

    const handleQuantityChange = (e) => {
        setQuantity(e.target.value);
    }


    return (
        <Container>
            {product ? (
                <Card>
                    <CardMedia
                        component="img"
                        alt={product.title} // Alternate text for accessibility
                        height="300"
                        image={product.image || '/placeholder-image.png'} // Use a placeholder image if product.image is not available
                    />
                    <CardContent>
                        <Typography variant="h5" component="div" sx={{marginBottom: 2}}>
                            {product.title}
                        </Typography>
                        <Typography variant="body2" color="textSecondary" component="p" sx={{marginBottom: 2}}>
                            {product.description}
                        </Typography>
                        <Typography gutterBottom variant="h6" color="textSecondary" component="div" sx={{marginBottom: 2}}>
                            Price: ${product.price}
                        </Typography>
                        <TextField
                            label="Quantity"
                            type="number"
                            value={quantity}
                            sx={{marginBottom: 2}}
                            onChange={handleQuantityChange}
                        />
                        <Box sx={{marginBottom: 2}}>
                            <Button variant="contained" color="primary">
                                Place Order
                            </Button>
                        </Box>

                    </CardContent>
                </Card>
            ) : (
                <Typography variant="h4">Loading...</Typography>
            )}
        </Container>
    );
};

export default ProductDetails;
