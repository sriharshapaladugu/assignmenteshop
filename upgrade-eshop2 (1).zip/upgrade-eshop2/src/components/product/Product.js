import React from 'react';
import {Card, CardActions, CardContent, CardMedia, Link, Typography} from '@mui/material';
import IconButton from "@mui/material/IconButton";
import FavoriteIcon from '@mui/icons-material/Favorite';
import ShareIcon from '@mui/icons-material/Share';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';


function Product({product, isAdmin = false, isLoggedIn}) {

    const cardStyle = {
        height: '100%',
    };

    return (
        <Card style={cardStyle}>
            <Link href={`/product/${product.id}`}>

            <CardMedia
                sx={{height: 140}}
                image={product.image}
                title={product.name}
            />
            </Link>
            <CardContent>
                <Typography gutterBottom variant="h5" component="div">
                    {product.name}
                </Typography>
                <Typography variant="body2" color="text.secondary" height={40}>
                    {product.description}
                </Typography>
                <Typography variant="body2" color="text.primary" fontWeight={'bold'} textAlign={'right'}>
                    $ {product.price}
                </Typography>
            </CardContent>
            <CardActions sx={{display: 'flex', justifyContent: 'space-between'}}>
                <div>
                    <IconButton aria-label="add to favorites">
                        <FavoriteIcon/>
                    </IconButton>
                    <IconButton aria-label="share">
                        <ShareIcon/>
                    </IconButton>
                </div>

                {isAdmin && <div>
                    <IconButton aria-label="edit">
                        <EditIcon/>
                    </IconButton>
                    <IconButton aria-label="delete">
                        <DeleteIcon/>
                    </IconButton>
                </div>
                }
                {/*<Button size="small">Share</Button>*/}
                {/*<Button size="small">Learn More</Button>*/}
            </CardActions>
        </Card>
    );
}

export default Product;
