import React from 'react';
import {Grid} from '@mui/material';
import Product from './Product'; // Import the Product component
import Container from "@mui/material/Container";

function ProductList({products, isAdmin, isLoggedIn}) {

    return (
        <Container>
            <Grid sx={{flexGrow: 1}}
                  container
                  direction="row"
                  justifyContent="center"
                  alignItems="center"
                  spacing={2}>
                {products.map((product) => (
                    <Grid item xs={12} sm={6} md={4} key={product.id}>
                        <Product product={product} isAdmin={isAdmin} isLoggedIn={isLoggedIn}/>
                    </Grid>
                ))}
                <style>
                    {`
                      .MuiGrid-container > .MuiGrid-item:last-child {
                        justify-content: flex-end;
                        text-align: right;
                      }
                    `}
                </style>
            </Grid>
        </Container>
    );
}

export default ProductList;
