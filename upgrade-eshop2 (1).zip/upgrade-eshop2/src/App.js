import './App.css';
import React, {useEffect, useState} from 'react';
import CategoryTabs from "./components/ToggleButton/CategoryTabs";
import SortBy from "./components/ToggleButton/SortBy";
import Container from "@mui/material/Container";
import Box from "@mui/material/Box";
import ResponsiveAppBar from "./components/NavBar/ResponsiveAppBar"
import ProductList from "./components/product/ProductList";
import {useLocation, useParams} from "react-router-dom";
import listOfProducts from './components/product/products.json'
import ProductDetails from "./components/product/ProductDetails";


function App() {
    const { id } = useParams();
    const [product, setProduct] = useState(null);
    const categories = ['All', 'Smartphones', 'Tops', 'Furniture', 'Womens-shoes'];
    const [selectedCategory, setSelectedCategory] = useState('All');
    const [selectedSortingOption, setSelectedSortingOption] = useState('default');

    const sortingOptions = [
        {value: 'default', label: 'Default'},
        {value: 'price-low-to-high', label: 'Price: Low to High'},
        {value: 'price-high-to-low', label: 'Price: High to Low'},
        {value: 'newest', label: 'Newest'},
    ];

    const [products, setProducts] = useState([{
        id: 123,
        name: 'Test product',
        image: 'imageUrl',
        price: 100
    }]);

    const location = useLocation();
    const isLoggedIn = location?.state?.isLoggedIn;
    const isAdmin = location?.state?.isAdmin;

    const handleSortingChange = (event) => {

        const {value: selectedValue} = event.target;
        setSelectedSortingOption(event.target.value);
        // Handle sorting change logic here, e.g., re-order the product list
        let actualProducts = [...products];

        // sort Prods by event.target.value
        // setProducts(prods);
        actualProducts.sort((a, b) => {
            if (selectedValue === 'price-low-to-high') {
                return a.price - b.price;
            } else if (selectedValue === 'price-high-to-low') {
                return b.price - a.price;
            } else if (selectedValue === 'newest') {
                return a.id - b.id;
            }
            return 0;
        });
        if (selectedValue === 'default') {
            actualProducts = listOfProducts;
        }

        setProducts(actualProducts);


    };

    useEffect(() => {
        setProducts(listOfProducts);
    }, []);


    const handleCategoryChange = (newCategory) => {
        setSelectedCategory(newCategory);
        // Handle category change logic here, e.g., filter the product list
        let actualProducts = [...listOfProducts];
        if (newCategory !== 'All') {
            actualProducts = actualProducts.filter((product) => product.category === newCategory.toLowerCase());
        } else {
            actualProducts = listOfProducts;
        }
        setProducts(actualProducts);
    };

    const onSearchForMe = (searchQuery) => {
        let actualProducts = [...listOfProducts];
        actualProducts = actualProducts.filter((product) => product.description.toLowerCase().includes(searchQuery?.toLowerCase()));
        setProducts(actualProducts);
    }

    useEffect(() => {
        if (id) {
            console.log(id);
            console.log(listOfProducts);
            const selectedOne = listOfProducts.find(item => item.id === (id - 0));
            console.log(selectedOne);
            setProduct(selectedOne);
        }
    });

    return (
        <Box>
            <ResponsiveAppBar
                isLoggedIn={isLoggedIn}
                searchForMe={onSearchForMe}
                isAdmin={isAdmin}></ResponsiveAppBar>
            <Container>
                <div style={{display: 'flex', justifyContent: 'center'}}>
                    <CategoryTabs minWidth={120}
                                  categories={categories}
                                  selectedCategory={selectedCategory}
                                  onSelectCategory={handleCategoryChange}
                    />

                </div>

                <div style={{display: 'flex', justifyContent: 'left', marginBottom: '12px'}}>
                    {!id && <SortBy
                        options={sortingOptions}
                        selectedOption={selectedSortingOption}
                        onOptionChange={handleSortingChange}
                    />}
                </div>
            </Container>
            {!id && <ProductList isLoggedIn={isLoggedIn} isAdmin={isAdmin} products={products}/>}
            {id && <ProductDetails isLoggedIn={isLoggedIn} isAdmin={isAdmin} product={product}/>}
        </Box>

    );
}

export default App;
